class Area{
    public static void main(String[] args) {
        Rectangle rectangle= new Rectangle();

        int result = rectangle.getArea(30,40);
        System.out.println(result);
    }
}
