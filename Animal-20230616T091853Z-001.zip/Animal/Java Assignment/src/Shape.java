public abstract class Shape {

    abstract int getArea(int length, int width);
}
