import java.security.PublicKey;

public abstract class Animal {

    abstract String  eat();
    abstract String sleep();
}
