public class Cat extends Animal {

    @Override
    String eat() {
        return("Cat is not eating");
    }
    @Override
    String sleep() {
        return ("Cat is not sleeping");
    }
}