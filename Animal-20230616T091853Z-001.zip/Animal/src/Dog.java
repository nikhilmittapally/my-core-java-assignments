public class Dog extends Animal {
    @Override
    String eat() {
        return ("Dog is eating");

    }

    @Override
    String  sleep() {
        return ("Dog is sleeping");
    }
}
