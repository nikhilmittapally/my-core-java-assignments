public class Car extends Vehicle{
    public Car(String make, String model) {
        super(make, model);
    }
    String drive(){

        return make+model+"is super fast";
    }
}



