public class Truck extends Vehicle{
    public Truck(String make, String model) {
        super(make, model);
    }
    String drive(){
        return "Truck is slow:"+model+make;
    }
}



