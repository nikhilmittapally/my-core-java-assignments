public class Main {
    public static void main(String[] args) {
                Car car=new Car("toyota","camry");
                Truck truck=new Truck("Ashokleyland","dcm");
                System.out.println(car.drive());
                System.out.println(truck.drive());
                    }



                }

