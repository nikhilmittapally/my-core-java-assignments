public class UseArguments {

    public static void main(String[] args) {
            System.out.print("Hi,Bob ");
            System.out.println(" .How are you?");


    }
}
