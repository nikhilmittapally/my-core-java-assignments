package com;

public class kusha {
    String getage() {

        return "son of rama";
    }
    string getlocation() {

    }

}
