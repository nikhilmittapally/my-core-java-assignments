package com;

public class lava extends kusha{

}