package com;

public interface krishna {
    int gettotalage();
    int getheight();
    string gettotaldetails();
}
