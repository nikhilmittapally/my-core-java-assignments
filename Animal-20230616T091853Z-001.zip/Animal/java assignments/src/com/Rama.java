package com;

 class Rama{
    string slogan="king of ayodhya";

    string getSlogan() {
        return slogan;
    }
}
