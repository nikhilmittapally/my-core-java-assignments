package com;

public class lava extends kusha {
    string getage();
    return(brotherofkusha);
}
