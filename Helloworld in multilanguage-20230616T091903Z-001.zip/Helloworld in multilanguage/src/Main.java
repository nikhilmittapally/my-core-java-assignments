public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        System.out.println("Hola Mundo!");
        System.out.println("Bonjour le monde!");
        System.out.println("Hallo welt1");
        System.out.println("Ciao Mono!");
        System.out.println("Ola Mono!");
        System.out.println("Namaste Dunia");
        System.out.println("Namaskaram Prapancham");
        System.out.println("Saluton mono!");
        System.out.println("Hallo wrald!");

    }
}
